AOS.init();




// start navbar Selection
// window.onscroll = function() {toggleNavbarOnScroll()};

//   function toggleNavbarOnScroll() {
//     const navbar = document.querySelector('.navbar');
//     if (window.scrollY > 50) { // When scrolled down 50px or more
//       navbar.classList.add('scrolled');
//     } else {
//       navbar.classList.remove('scrolled');
//     }
//   }

// end navbar Selection












// start top scroll buton // Get the button

// Get the button element
const scrollToTopBtn = document.getElementById("scrollToTopBtn");

// Show or hide the button based on scroll position
window.onscroll = function () {
  toggleNavbarOnScroll(); // Include navbar scroll logic
  toggleScrollToTopButton(); // Include scroll-to-top button logic
};

function toggleNavbarOnScroll() {
  const navbar = document.querySelector('.navbar');
  if (window.scrollY > 50) { // When scrolled down 50px or more
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
}

function toggleScrollToTopButton() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    scrollToTopBtn.style.display = "block"; // Show button
  } else {
    scrollToTopBtn.style.display = "none"; // Hide button
  }
}

// Smooth scroll to top when the button is clicked
scrollToTopBtn.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
});


// end top scroll buton 








// start image section 
filterSelection("all");

function filterSelection(c) {
  let columns = document.getElementsByClassName("column");
  if (c === "all") c = "";
  Array.from(columns).forEach((column) => {
    column.style.display = column.className.indexOf(c) > -1 ? "block" : "none";
  });
}

function openModal(src) {
  const modalImage = document.getElementById("modalImage");
  modalImage.src = src;
  const modal = new bootstrap.Modal(document.getElementById("imageModal"));
  modal.show();
}
// end image section 



